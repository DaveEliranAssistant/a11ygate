**SAMPLE**: Example Ltd is a fictional customer. All data comes from the A11yGate demo app (fixtures/demo-app), not a customer site.

# A11yGate evidence pack — http://127.0.0.1:4173/

> Automated testing only. Not a WCAG audit, certification or legal advice.

## Scope scanned

- Start URL: `http://127.0.0.1:4173/`
- Origin: `http://127.0.0.1:4173`
- Scanned at (UTC): 2026-11-26T09:00:00.000Z
- Commit: unavailable (not recorded; none was invented)
- Pages analysed: 4; failed: 0; links not followed: 0; crawl cap: 10
- robots.txt: robots.txt returned HTTP 404; no rules applied.
- Engines and rule sets: axe 4.14.0 — axe-core rules filtered by tags \[wcag2a, wcag2aa, wcag21a, wcag21aa, wcag22a, wcag22aa, best-practice\]

| Page | HTTP | Status | Findings |
| --- | --- | --- | --- |
| http://127.0.0.1:4173/ | 200 | complete | 1 |
| http://127.0.0.1:4173/products.html | 200 | complete | 1 |
| http://127.0.0.1:4173/checkout.html | 200 | complete | 2 |
| http://127.0.0.1:4173/about.html | 200 | complete | 1 |

## Automated result

Verdict: **FAIL** (fail on: serious). 1 new finding at or above serious.

| Severity | Findings |
| --- | --- |
| critical | 3 |
| serious | 1 |
| moderate | 1 |
| minor | 0 |
| unknown | 0 |

Full findings: `scan/a11ygate-scan.md` and `scan/a11ygate-scan.html`.

## What automated testing cannot cover

This pack records what automated rules detected on the pages listed above. It does not assess:

- Most WCAG success criteria need human judgement. Automated rules detect only a subset of accessibility barriers, so an empty findings list is not evidence of conformance.
- Whether text alternatives, form labels, headings, link text and page titles are accurate and meaningful. Tools can only check that they exist.
- Keyboard operability across complete user journeys, logical focus order, visible focus in context and keyboard traps that appear after interaction.
- The experience with screen readers, magnifiers, voice control and other assistive technology.
- Login journeys, forms, multi-step flows, error states, menus, dialogs and other interactions beyond the pages explicitly scanned.
- Pages that were not reached: not linked through same-origin a[href] links, beyond the crawl cap, disallowed by robots.txt, or failed to load.
- Captions, transcripts and audio description for time-based media, and whether they are correct.
- Cognitive and learning accessibility: plain language, consistent navigation, timing, and error prevention and recovery.
- Reflow, zoom, orientation and user style or contrast settings beyond what individual rules check.
- Documents (PDF, office files), native apps, emails and third-party services that were not rendered in the scanned pages.

Manual testing by people, including people with disabilities and assistive technology users, is needed for these areas.

## Scope boundaries

- Only scan sites you own or are explicitly authorized to test.
- Automated testing only: axe-core detects a subset of WCAG issues. Absence of findings is not conformance, certification or legal advice.
- Read-only: pages were loaded without logging in, filling forms or clicking. Authenticated areas, interactions and dynamic states are unassessed.
- Only same-origin pages reachable through a\[href\] links \(at most 20\) were visited; robots.txt Disallow rules were honoured.

## Contents of this pack

- `report.md`
- `report.html`
- `engines/axe.json`
- `scan/a11ygate-scan.html`
- `scan/a11ygate-scan.json`
- `scan/a11ygate-scan.junit.xml`
- `scan/a11ygate-scan.md`
- `scan/a11ygate-scan.sarif`
- `manifest.json` — versions, commit, UTC timestamps and the SHA-256 of every other file

Automated testing only. Not a WCAG audit, certification or legal advice.
