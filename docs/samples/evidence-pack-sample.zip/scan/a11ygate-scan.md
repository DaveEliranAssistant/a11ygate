**SAMPLE**: Example Ltd is a fictional customer. All data comes from the A11yGate demo app (fixtures/demo-app), not a customer site.

# A11yGate site scan — http://127.0.0.1:4173/

**Verdict: FAIL** (fail on: serious)

1 new finding at or above serious.

| Severity | Findings |
| --- | --- |
| critical | 3 |
| serious | 1 |
| moderate | 1 |
| minor | 0 |
| unknown | 0 |

Scanned: 2026-11-26T09:00:00.000Z. Pages analysed: 4; failed: 0. axe-core 4.14.0; A11yGate 0.2.0.

Baseline: 1 new; 4 existing; 0 fixed; 0 unassessed.

Automated testing only. Not a WCAG audit, certification or legal advice.

## Pages

| Page | HTTP | Status | Findings |
| --- | --- | --- | --- |
| http://127.0.0.1:4173/ | 200 | complete | 1 |
| http://127.0.0.1:4173/products.html | 200 | complete | 1 |
| http://127.0.0.1:4173/checkout.html | 200 | complete | 2 |
| http://127.0.0.1:4173/about.html | 200 | complete | 1 |

## Findings by WCAG criterion

### WCAG 1.1.1 Non-text Content (A); EN 301 549 9.1.1.1

- [existing] **image-alt** (critical) on `http://127.0.0.1:4173/` — `img` — Images must have alternative text — [rule guidance](https://dequeuniversity.com/rules/axe/4.14/image-alt?application=playwright)

### WCAG 1.4.3 Contrast (Minimum) (AA); EN 301 549 9.1.4.3

- [existing] **color-contrast** (serious) on `http://127.0.0.1:4173/products.html` — `li:nth-child(1) > .price-tag` — Elements must meet minimum color contrast ratio thresholds — [rule guidance](https://dequeuniversity.com/rules/axe/4.14/color-contrast?application=playwright)

### WCAG 4.1.2 Name, Role, Value (A); EN 301 549 9.4.1.2

- [new] **button-name** (critical) on `http://127.0.0.1:4173/checkout.html` — `.remove-item` — Buttons must have discernible text — [rule guidance](https://dequeuniversity.com/rules/axe/4.14/button-name?application=playwright)
- [existing] **label** (critical) on `http://127.0.0.1:4173/checkout.html` — `#email` — Form elements must have labels — [rule guidance](https://dequeuniversity.com/rules/axe/4.14/label?application=playwright)

### Best practice (no WCAG success criterion mapped)

- [existing] **heading-order** (moderate) on `http://127.0.0.1:4173/about.html` — `h4` — Heading levels should only increase by one — [rule guidance](https://dequeuniversity.com/rules/axe/4.14/heading-order?application=playwright)

## Findings by severity

### critical (3)

- [existing] **image-alt** (critical) on `http://127.0.0.1:4173/` — `img` — Images must have alternative text — [rule guidance](https://dequeuniversity.com/rules/axe/4.14/image-alt?application=playwright)
- [new] **button-name** (critical) on `http://127.0.0.1:4173/checkout.html` — `.remove-item` — Buttons must have discernible text — [rule guidance](https://dequeuniversity.com/rules/axe/4.14/button-name?application=playwright)
- [existing] **label** (critical) on `http://127.0.0.1:4173/checkout.html` — `#email` — Form elements must have labels — [rule guidance](https://dequeuniversity.com/rules/axe/4.14/label?application=playwright)

### serious (1)

- [existing] **color-contrast** (serious) on `http://127.0.0.1:4173/products.html` — `li:nth-child(1) > .price-tag` — Elements must meet minimum color contrast ratio thresholds — [rule guidance](https://dequeuniversity.com/rules/axe/4.14/color-contrast?application=playwright)

### moderate (1)

- [existing] **heading-order** (moderate) on `http://127.0.0.1:4173/about.html` — `h4` — Heading levels should only increase by one — [rule guidance](https://dequeuniversity.com/rules/axe/4.14/heading-order?application=playwright)

## Scope and boundaries

- Only scan sites you own or are explicitly authorized to test.
- Automated testing only: axe-core detects a subset of WCAG issues. Absence of findings is not conformance, certification or legal advice.
- Read-only: pages were loaded without logging in, filling forms or clicking. Authenticated areas, interactions and dynamic states are unassessed.
- Only same-origin pages reachable through a\[href\] links \(at most 20\) were visited; robots.txt Disallow rules were honoured.

Automated checks cover only part of WCAG; this is evidence, not certification.
Informational only. Not legal advice. Not a certification of EAA compliance.
